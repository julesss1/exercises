package virtual.proxy

import java.util.List

//remove if not needed
import scala.collection.JavaConversions._

object TestVirtualProxy {

  def main(args: Array[String]): Unit = {
var contactList: ContactList = new ContactListProxyImpl()
       val company: Company =
         new Company("ABC Company", "Alabama", "011-2845-8965", contactList)
       println("Company Name: " + company.getCompanyName)
       println("Company Address: " + company.getCompanyAddress)
       println("Company Contact No.: " + company.getCompanyContactNo)
       println("Requesting for contact list")
       contactList = company.getContactList
       val empList: List[Employee] = contactList.getEmployeeList
       for (emp <- empList) {
         println(emp)
       }
  }

}
