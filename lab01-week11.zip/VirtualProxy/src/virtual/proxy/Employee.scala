package virtual.proxy

import scala.beans.{BeanProperty, BooleanBeanProperty}

import scala.collection.JavaConversions._

class Employee(@BeanProperty var employeeName: String,
               @BeanProperty var employeeSalary: Double,
               @BeanProperty var employeeDesignation: String) {

  override def toString(): String =
    "Employee Name: " + employeeName + ", EmployeeDesignation: " +
      employeeDesignation +
      ", Employee Salary: " +
      employeeSalary

}
