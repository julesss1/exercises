package virtual.proxy

import scala.beans.BeanProperty

class Company(@BeanProperty var companyName: String,
              @BeanProperty var companyAddress: String,
              @BeanProperty var companyContactNo: String,
              @BeanProperty var contactList: ContactList) {

  println("Company object created...")

}