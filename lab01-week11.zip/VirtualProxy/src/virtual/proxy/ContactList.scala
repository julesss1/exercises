package virtual.proxy

import java.util.List

//remove if not needed
import scala.collection.JavaConversions._

trait ContactList {

  def getEmployeeList(): List[Employee]

}
