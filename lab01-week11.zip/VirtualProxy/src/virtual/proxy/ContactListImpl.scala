package virtual.proxy

import scala.collection.JavaConversions._
import java.util.ArrayList
import java.util.List;

class ContactListImpl extends ContactList {

  private def getEmpList(): List[Employee] = {
    val empList: List[Employee] = new ArrayList[Employee](5)
    empList.add(new Employee("Employee A", 23434, "SE"))
    empList.add(new Employee("Employee B", 224534, "Manager"))
    empList.add(new Employee("Employee C", 546654, "SSE"))
    empList.add(new Employee("Employee D", 45445.12, "SSE"))
    empList.add(new Employee("Employee E", 2847.01, "SE"))
    empList
  }
  
  override def getEmployeeList(): List[Employee] = getEmpList()

}