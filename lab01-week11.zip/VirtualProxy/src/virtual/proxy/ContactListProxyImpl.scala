package virtual.proxy

import java.util.ArrayList;
import java.util.List;

class ContactListProxyImpl extends ContactList {

  private var contactList: ContactList = _

  override def getEmployeeList(): List[Employee] = {
    if (contactList == null) {
      println("Creating contact list and fetching list of employees...")
      contactList = new ContactListImpl()
    }
    contactList.getEmployeeList
  }

}