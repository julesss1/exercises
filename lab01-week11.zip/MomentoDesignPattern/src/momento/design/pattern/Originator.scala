package momento.design.pattern
import scala.beans.{BeanProperty, BooleanBeanProperty}

import scala.collection.JavaConversions._

class Originator(@BeanProperty var x: Double,
                 @BeanProperty var y: Double,
                 var careTaker: CareTaker) {

  private var lastUndoSavepoint: String = _
  createSavepoint("INITIAL")

  def createSavepoint(savepointName: String): Unit = {
    careTaker.saveMemento(new Memento(this.x, this.y), savepointName)
    lastUndoSavepoint = savepointName
  }

  def undo(): Unit = {
     setOriginatorState(lastUndoSavepoint);
  }

  def undo(savepointName: String): Unit = {
     setOriginatorState(savepointName);
  }

  def undoAll(): Unit = {
    setOriginatorState("INITIAL");
    careTaker.clearSavepoints()
  }

  private def setOriginatorState(savepointName: String): Unit = {
    val mem: Memento = careTaker.getMemento(savepointName)
    this.x = mem.getX
    this.y = mem.getY
  }

  override def toString(): String = "X: " + x + ", Y: " + y

}
