package momento.design.pattern

import scala.beans.BeanProperty

class Memento(@BeanProperty var x: Double, @BeanProperty var y: Double)
