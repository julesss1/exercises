package momento.design.pattern

object TestMementoPattern {

  def main(args: Array[String]): Unit = {
    val careTaker: CareTaker = new CareTaker()
    val originator: Originator = new Originator(5, 10, careTaker)
    println("Default State: " + originator)
    originator.setX(originator.getY * 51)
    println("State: " + originator)
    originator.createSavepoint("SAVE1")
    originator.setY(originator.getX / 22)
    println("State: " + originator)
    originator.undo()
    println("State after undo: " + originator)
    originator.setX(Math.pow(originator.getX, 3))
    originator.createSavepoint("SAVE2")
    println("State: " + originator)
    originator.setY(originator.getX - 30)
    originator.createSavepoint("SAVE3")
     println("State: " + originator)
    originator.setY(originator.getX / 22)
    originator.createSavepoint("SAVE4")
    println("State: " + originator)
    originator.undo("SAVE2")
    println("Retrieving at: " + originator)
    originator.undoAll()
    println("State after undo all: " + originator)
  }

}