package momento.design.pattern

import java.util.HashMap
import java.util.Map;


class CareTaker {

  private val savepointStorage: Map[String, Memento] =
    new HashMap[String, Memento]()

  def saveMemento(memento: Memento, savepointName: String): Unit = {
    println("Saving state..." + savepointName)
    savepointStorage.put(savepointName, memento)
  }

  def getMemento(savepointName: String): Memento = {
    println("Undo at ..." + savepointName)
    savepointStorage.get(savepointName)
  }

  def clearSavepoints(): Unit = {
    println("Clearing all save points...")
    savepointStorage.clear()
  }

}