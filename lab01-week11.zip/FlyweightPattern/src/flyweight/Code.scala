package flyweight

import scala.beans.BeanProperty

class Code {

  @BeanProperty
  var code: String = _

}