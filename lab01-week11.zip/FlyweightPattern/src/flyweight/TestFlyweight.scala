package flyweight

object TestFlyweight {

  def main(args: Array[String]): Unit = {
    var code: Code = new Code()
    code.setCode("C Code...")
    var platform: Platform = PlatformFactory.getPlatformInstance("C")
    platform.execute(code)
    println("-" * 20)
    code = new Code()
    code.setCode("C Code2...")
    platform = PlatformFactory.getPlatformInstance("C")
    platform.execute(code)
    println("-" * 20)
    code = new Code()
    code.setCode("JAVA Code...")
    platform = PlatformFactory.getPlatformInstance("JAVA")
    platform.execute(code)
    println("-" * 20)
    code = new Code()
    code.setCode("JAVA Code2...")
    platform = PlatformFactory.getPlatformInstance("JAVA")
    platform.execute(code)
    println("-" * 20)
    code = new Code()
    code.setCode("RUBY Code...")
    platform = PlatformFactory.getPlatformInstance("RUBY")
    platform.execute(code)
    println("-" * 20)
    code = new Code()
    code.setCode("RUBY Code2...")
    platform = PlatformFactory.getPlatformInstance("RUBY")
    platform.execute(code)
    code = new Code()
    code.setCode("Scala Code...")
    platform = PlatformFactory.getPlatformInstance("SCALA")
    platform.execute(code)
  }

}
