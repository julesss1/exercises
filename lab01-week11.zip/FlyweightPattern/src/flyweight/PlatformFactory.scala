package flyweight

import java.util.Map;
import java.util.HashMap;

object PlatformFactory {

  private var map: Map[String, Platform] = new HashMap()

  def getPlatformInstance(platformType: String): Platform = synchronized {
    var platform: Platform = map.get(platformType)
    if (platform == null) {
      platformType match {
        case "C" => platform = new CPlatform()
        case "CPP" => platform = new CPPPlatform()
        case "JAVA" => platform = new JavaPlatform()
        case "RUBY" => platform = new RubyPlatform()
        case "SCALA" => platform = new ScalaPlatform()

      }
      map.put(platformType, platform)
    }
    platform
  }

}