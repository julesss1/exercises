package flyweight

class CPPPlatform extends Platform {

  println("CPPPlatform object created")

  override def execute(code: Code): Unit = {
    println("Compiling and executing CPP code.")
  }

}
