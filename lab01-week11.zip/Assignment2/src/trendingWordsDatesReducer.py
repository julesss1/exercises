#!/usr/bin/env python

import sys
import operator

current_date = None
word_count = {}
date = None

# input comes from STDIN
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()

    try:
        # parse the input we got from mapper.py
        date_word, count = line.split('\t') 
        # convert count (currently a string) to int
        count = int(count)
        date, word = date_word.split('_')
        # this IF-switch only works because Hadoop sorts map output
        # by key (here: word) before it is passed to the reducer
        if current_date == date:
            word_count[word]=count
        else:
            if current_date:
                result=sorted(word_count.iteritems(), key=operator.itemgetter(1), reverse=True)[:5]
                result=map(lambda x:x[0]+":"+str(x[1]),result)
                
                for wc in result:
                    # write result to STDOUT
                    print '%s\t%s' % (current_date, wc)
            
            word_count = {} #clear the dictionary
            current_date = date
            word_count[word]=count
    except ValueError:
        # count was not a number, so silently
        # ignore/discard this line
        continue
    
# last record
if current_date == date:
    result=sorted(word_count.iteritems(), key=operator.itemgetter(1), reverse=True)[:5]
    result=map(lambda x:x[0]+":"+str(x[1]),result)
                
    for wc in result:
        # write result to STDOUT
        print '%s\t%s' % (current_date, wc)

