#!/usr/bin/env python

import sys
import collections
import operator
from collections import OrderedDict

current_date = None
current_count = 0
word = None
date = None
dname={}
# input comes from STDIN
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()

    try:
        # parse the input we got from mapper.py
        date_word, count = line.split(':') 
        # convert count (currently a string) to int
        count = int(count)
        date, word = date_word.split('_')
        # this IF-switch only works because Hadoop sorts map output
        # by key (here: word) before it is passed to the reducer
        if current_date == date:
            dname[date_word] = count
        else:
            if current_date:
                # write result to STDOUT
                sorted_x=OrderedDict(sorted(dname.iteritems(), key=operator.itemgetter(1), reverse=True)[:5])
                for w in sorted_x:
                    print w, sorted_x[w]
                dname.clear()
#                   print counter.most_common(5)
#                 print '%s\t%s' % (current_word, current_count)
#             current_count = count
            current_date = date
            dname[date_word] = count
    except ValueError:
        # count was not a number, so silently
        # ignore/discard this line
        continue
# do not forget to output the last word if needed!
if current_date == date:
    sorted_x=OrderedDict(sorted(dname.iteritems(), key=operator.itemgetter(1), reverse=True)[:5])
    for w in sorted_x:
        print w, sorted_x[w]
        dname.clear()
#     print '%s\t%s' % (current_word, current_count)

