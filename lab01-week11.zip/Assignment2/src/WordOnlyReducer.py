#!/usr/bin/env python

import sys

# input comes from STDIN
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()

    try:
        # parse the input we got from mapper.py
        word= line.split(':')[0]
        print(word)
    except ValueError:
        continue
  

    