'''
Created on Apr 30, 2017

@author: Aneela
'''
#!/Users/Aneela/anaconda/bin/conda
from pandas import DataFrame, read_csv
import pandas as pd
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import csv
import re
from collections import Counter

#nltk.download()

Location = r'/Users/Aneela/Downloads/Tweets.csv'
#wr = csv.writer(outputfile_1, quoting=csv.QUOTE_ALL)

df = pd.read_csv(Location)

#tokenized_docs = [word_tokenize(doc) for doc in df]
#filtered_tweets = [w for w in df if not w in stopwords.words('english')]
#print('tokenized docs ',tokenized_docs)

print('filteres tweets ',df['text'])


