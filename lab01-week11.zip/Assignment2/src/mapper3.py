#!/usr/bin/env python

import sys
import csv
# import os library to get os path etc
import os
# glob library is used to match paths of files
import glob
# regular expressions library
import re
# string library to manipulates strings
from string import digits
import string
# import stop words from nltk corpus
from nltk.corpus import stopwords
# import nltk object
import nltk
# datetime library
import datetime
# input comes from STDIN (standard input)

from nltk.stem import PorterStemmer

# a function to remove digits from a line
def removeDigits(line):
    return line.translate(None, digits)
# a function to remove stop words from a line
def removeNLTKStopWords(line):
    # make a regex to remove stop words
    pattern = re.compile(r'\b(' + r'|'.join(stopwords.words('english')) + r')\b\s*')
    # remove the matching stop words
    text = pattern.sub(' ', line)
    return text
#lower case
def toLower(line):
    return line.lower()
# a function to remove symbols from a line
def removePunctuaions(line):
    # remove special symbols
    return line.translate(None, '?.\',\"/\|%^&*!@#$()_-+=}]{[<>:;~') 
# a function that replaces non ascii characters
def removeNonASCII(line):
    return re.sub(r'[^\x00-\x7F]+', ' ', line)
# remove unwanted spaces
def removeExtraSpaces(line):
    return re.sub("\s\s+", " ", line)

nltk.download("stopwords")
ps = PorterStemmer()

# input comes from STDIN (standard input)
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()
    tokens=list(csv.reader([line]))[0]
   
    try:
        text=tokens[10]
        dateTime=tokens[12]
       
         #conver to lower case
        text=toLower(text)
        # remove digit from the line
        text = removeDigits(text)
        # remove symbols
        text = removePunctuaions(text)
        # remove stop words
        text = removeNLTKStopWords(text)
        text = removeNonASCII(text)
        text = removeExtraSpaces(text)
         
        words = text.split()
         
        # split the dateTime into date
        dateTime=dateTime.strip()
        dateTime=dateTime.split()
        date = dateTime[0]
        # increase counters
        for word in words:
            key=date+"_"+ps.stem(word)
            print '%s:%s' % (key, 1)
    except:
        print tokens