#!/usr/bin/env python

import sys
import csv
# input comes from STDIN (standard input)
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()
#     tokens=list(csv.reader([line]))[0]
#     try:
#         text=tokens[10]
#         # split the line into words
#         words = text.split()
#         # increase counters
#         for word in words:
    print line
#     except:
#         print tokens