package protection.proxy

import java.rmi.Naming
import scala.collection.JavaConversions._

class ReportGeneratorProtectionProxy(var staff: Staff)
    extends ReportGeneratorProxy {

  var reportGenerator: ReportGenerator = _

  override def generateDailyReport(): String =
    if (staff.isOwner) {
      var reportGenerator: ReportGenerator = null
      try {
        reportGenerator = Naming
          .lookup("rmi://127.0.0.1/remoteGenerator")
          .asInstanceOf[ReportGenerator]
        reportGenerator.generateDailyReport()
      } catch {
        case e: Exception => e.printStackTrace()

      }
      ""
    } else {
      "Not Authorized to view report."
    }

}
