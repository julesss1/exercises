package protection.proxy

trait ReportGeneratorProxy {

  def generateDailyReport(): String

}
