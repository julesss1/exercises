package protection.proxy

import java.rmi.Remote

import java.rmi.RemoteException

//remove if not needed
import scala.collection.JavaConversions._

trait ReportGenerator extends Remote {

  def generateDailyReport(): String

}