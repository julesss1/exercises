package command.design
class FileIO {

  def execute(): Unit = {
    println("Executing File IO operations...")
  }

}