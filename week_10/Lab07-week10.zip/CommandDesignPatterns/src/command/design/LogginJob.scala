package command.design

class LoggingJob extends Job {

  private var logging: Logging = _

  def setLogging(logging: Logging): Unit = {
    this.logging = logging
  }

  override def run(): Unit = {
    println(
      "Job ID: " + Thread.currentThread().getId + " executing logging jobs.")
    if (logging != null) {
      logging.log()
    }
    try Thread.sleep(1000)
    catch {
      case e: InterruptedException => Thread.currentThread().interrupt()

    }
  }

}