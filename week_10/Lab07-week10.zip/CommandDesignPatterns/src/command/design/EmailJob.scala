package command.design

class EmailJob extends Job {

  private var email: Email = _

  def setEmail(email: Email): Unit = {
    this.email = email
  }

  override def run(): Unit = {
    println(
      "Job ID: " + Thread.currentThread().getId + " executing email jobs.")
    if (email != null) {
      email.sendEmail()
    }
    try Thread.sleep(1000)
    catch {
      case e: InterruptedException => Thread.currentThread().interrupt()

    }
  }

}