package command.design

class FileIOJob extends Job {

  private var fileIO: FileIO = _

  def setFileIO(fileIO: FileIO): Unit = {
    this.fileIO = fileIO
  }

  override def run(): Unit = {
    println(
      "Job ID: " + Thread.currentThread().getId + " executing fileIO jobs.")
    if (fileIO != null) {
      fileIO.execute()
    }
    try Thread.sleep(1000)
    catch {
      case e: InterruptedException => Thread.currentThread().interrupt()

    }
  }

}
