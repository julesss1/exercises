package command.design

class Logging {

  def log(): Unit = {
    println("Logging...")
  }

}
