package command.design

class Email {

  def sendEmail(): Unit = {
    println("Sending email.......")
  }

}