package command.design

trait Job {

  def run(): Unit

}
