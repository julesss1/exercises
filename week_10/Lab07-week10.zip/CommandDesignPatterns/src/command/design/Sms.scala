package command.design

class Sms {

  def sendSms(): Unit = {
    println("Sending SMS...")
  }

}