package cor.pattern
import scala.beans.{BeanProperty, BooleanBeanProperty}


import scala.collection.JavaConversions._

class ImageFileHandler(@BeanProperty var handlerName: String) extends Handler {

  private var handler: Handler = _

  override def setHandler(handler: Handler): Unit = {
    this.handler = handler
  }

  override def process(file: File): Unit = {
    if (file.getFileType.==("image")) {
      println("Process and saving image file... by " + handlerName)
    } else if (handler != null) {
      println(handlerName + " fowards request to " + handler.getHandlerName)
      handler.process(file)
    } else {
      println("File not supported")
    }
  }

}
