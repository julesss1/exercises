package cor.pattern

import scala.beans.BeanProperty

class File(@BeanProperty val fileName: String,
           @BeanProperty val fileType: String,
           @BeanProperty val filePath: String)
