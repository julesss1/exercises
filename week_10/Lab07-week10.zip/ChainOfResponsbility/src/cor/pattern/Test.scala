package cor.pattern


object Test {

  def main(args: Array[String]): Unit = {
  var file:File = null
    val textHandler: Handler = new TextFileHandler("Text Handler");
    val docHandler: Handler = new DocFileHandler("Doc Handler");
    val excelHandler: Handler = new ExcelFileHandler("Excel Handler");
    val audioHandler: Handler = new AudioFileHandler("Audio Handler");
    val videoHandler: Handler = new VideoFileHandler("Video Handler");
    val imageHandler: Handler = new ImageFileHandler("Image Handler");
    textHandler.setHandler(docHandler)
    docHandler.setHandler(excelHandler)
    excelHandler.setHandler(audioHandler)
    audioHandler.setHandler(videoHandler)
    videoHandler.setHandler(imageHandler)
    file = new File("Abc.mp3", "audio", "C:");
    textHandler.process(file)
    println("---------------------------------")
     file = new File("Abc.jpg", "video", "C:")
    textHandler.process(file)
    println("---------------------------------")
    file = new File("Abc.doc", "doc", "C:")
          textHandler.process(file)
      println("---------------------------------")
      file = new File("Abc.bat", "bat", "C:")
      textHandler.process(file)
  }

}