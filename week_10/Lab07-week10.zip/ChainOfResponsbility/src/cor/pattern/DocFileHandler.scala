package cor.pattern

import scala.beans.{BeanProperty, BooleanBeanProperty}

import scala.collection.JavaConversions._

class DocFileHandler(@BeanProperty var handlerName: String) extends Handler {

  private var handler: Handler = _

  override def setHandler(handler: Handler): Unit = {
    this.handler = handler
  }

  override def process(file: File): Unit = {
    if (file.getFileType.==("doc")) {
      println("Process and saving doc file... by " + handlerName)
    } else if (handler != null) {
      println(handlerName + " fowards request to " + handler.getHandlerName)
      handler.process(file)
    } else {
      println("File not supported")
    }
  }

}