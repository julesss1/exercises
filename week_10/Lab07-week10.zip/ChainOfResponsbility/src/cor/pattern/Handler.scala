package cor.pattern

trait Handler {

  def setHandler(handler: Handler): Unit

  def process(file: File): Unit

  def getHandlerName(): String

}