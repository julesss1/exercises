package cor.pattern

import scala.beans.{BeanProperty, BooleanBeanProperty}

//remove if not needed
import scala.collection.JavaConversions._

class ExcelFileHandler(@BeanProperty var handlerName: String) extends Handler {

  private var handler: Handler = _

  override def setHandler(handler: Handler): Unit = {
    this.handler = handler
  }

  override def process(file: File): Unit = {
    if (file.getFileType.==("excel")) {
      println("Process and saving excel file... by " + handlerName)
    } else if (handler != null) {
      println(handlerName + " fowards request to " + handler.getHandlerName)
      handler.process(file)
    } else {
      println("File not supported")
    }
  }

}
