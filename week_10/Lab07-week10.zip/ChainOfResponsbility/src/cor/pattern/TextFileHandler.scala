package cor.pattern

import scala.beans.{BeanProperty, BooleanBeanProperty}

//remove if not needed
import scala.collection.JavaConversions._

class TextFileHandler(@BeanProperty var handlerName: String) extends Handler {

  private var handler: Handler = _

  override def setHandler(handler: Handler): Unit = {
    this.handler = handler
  }

  override def process(file: File): Unit = {
    if (file.getFileType.==("text")) {
      println("Process and saving text file... by " + handlerName)
    } else if (handler != null) {
      println(handlerName + " fowards request to " + handler.getHandlerName)
      handler.process(file)
    } else {
      println("File not supported")
    }
  }

}